var app = getApp()
Page({
	data: {},
	onLoad: function () {},
	onShow: function() {}
});

