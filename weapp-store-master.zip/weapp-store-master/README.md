# 微信小程序－DQ(上海七宝嘉茂店)

### 说明：

实现点餐功能。

### 数据接口:

使用本地数据

### 目录结构：

- imgs — 存放项目图片文件
- page — 存放项目页面文件
- utils — 存放格式化文件

### 开发环境：

微信web开发者工具 v0.11.122100

### 项目截图：

https://www.getweapp.com/project?projectId=58a574f252e1e8733dc567fe

### 感谢：

本项目原始版本由MMMsCheng提供：https://github.com/MMMsCheng/wxapp